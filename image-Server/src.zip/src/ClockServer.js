/**
 * This script allows create an auditor.
 * The auditor listens to musicians that play instruments, he listens to
 * musicians by using the protocol UDP by joining a multicast group.
 * The auditor considers that if a musician didn't play since 5 seconds,
 * he's dead.
 * The auditor can be joined by TCP and he just retruns a JSON array that
 * contains all the musicians that are alive.
 * An example of the contents of the JSON array is :
 *
 * author : 
 * date   : 11.05.2017
 */
// Load the http module to create an http server.
var http = require('http');
var url = ('url');
var server_adr = 'http:///challenge-b/test1';
var email = 'marie.lemdjonzinke@heig-vd.ch';
var accepts = require('accepts');

// Configure our HTTP server to respond with Hello World to all requests.
var server = http.createServer(function (request, response) {
	
	 var accept = accepts(request);
	 var q = url.parse(server_adr, true);
 
  // the order of this list is significant; should be server preferred order 
  switch(accept.type(['json', 'html'])) {
	case 'json':
	response.writeHead(200, {'Content-Type': 'application/json'});
	var message = {
		email : "marie.lemdjonzinke@heig-vd.ch"
	}
	var date = JSON.stringify(message);
	response.end(date);
      break;
    case 'html':
	response.writeHead(200, {'Content-Type':'text/html'});
	response.end('My adresse email is <b>' + email + '</b>');
		break;
    default:
		  // the fallback is text/plain, so no need to specify it above 
	response.writeHead(200, {'Content-Type': 'text/plain'});
	response.end('marie.lemdjonzinke@heig-vd.ch');
      break;
  }
});

// Listen on port 8000, IP defaults to 127.0.0.1
server.listen(8000);
 
console.log("HTTP server listening on port 8000 at localhost.");


